Documentation can be compiled using sphinx in the docs directory or found at:

http://www.ics.uci.edu/~sswamida/CROCpy3
