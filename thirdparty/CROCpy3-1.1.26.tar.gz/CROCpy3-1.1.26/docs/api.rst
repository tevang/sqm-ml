=================
The Croc API
=================

The Epydocs generated docs can be found `here <epydoc/index.html>`_.


.. automodule:: croc
    :members:
    :undoc-members:
