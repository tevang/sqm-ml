===========
R Interface
===========

As this module is written in pure-Python it is possible to interface directly with it using
one of several R-Python integration methods. Currently, this possiblity is not fully tested. In the future,
we plan to decide on and document a preferred interface method.
